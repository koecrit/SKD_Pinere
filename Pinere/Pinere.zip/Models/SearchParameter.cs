﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Pinere.Models
{
    public class SearchParameter
    {
        public string Search { get; set; }
        public string NamaAirline { get; set; }
        public string NamaAirlineDis { get; set; }
        public string NomorPenerbangan { get; set; }
        public string WaktuBerangkat { get; set; }
        public string KotaAsal { get; set; }
        public string KotaAsalDis { get; set; }
        public string KotaTujuan { get; set; }
        public string KotaTujuanDis { get; set; }
        public string TipeKotaTemp { get; set; }
        public string PenumpangSakit { get; set; }
        public List<SelectListItem> PenumpangSakitList { get; set; }
        public string RujukRS { get; set; }
        public List<SelectListItem> RujukRSList { get; set; }
        public string NamaPasien { get; set; }
        public string TanggalLahir { get; set; }
        public string RujukRSDis { get; set; }
        public string HasilDiagnosa { get; set; }
        public SearchParameter()
        {
            PenumpangSakitList = new List<SelectListItem>();
            PenumpangSakitList.Add(new SelectListItem { Value = "", Text = "-- ALL --" });
            PenumpangSakitList.Add(new SelectListItem { Value = "1", Text = "Ada" });
            PenumpangSakitList.Add(new SelectListItem { Value = "2", Text = "Tidak" });
            RujukRSList = new List<SelectListItem>();
            RujukRSList.Add(new SelectListItem { Value = "", Text = "-- Silahkan Pilih --" });
            RujukRSList.Add(new SelectListItem { Value = "1", Text = "Ya" });
            RujukRSList.Add(new SelectListItem { Value = "2", Text = "Tidak" });
        }
    }
}