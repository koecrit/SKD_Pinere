﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Pinere.Helper;

namespace Pinere.Models
{
    public class Sampel
    {
        public int Id { get; set; }
        public string PasienId { get; set; }
        public string TanggalAmbilSampel { get; set; }
        public string JenisSpesimen { get; set; }
        public string JenisPemeriksaanLab { get; set; }
        public string TanggalKirimSampel { get; set; }
    }
}